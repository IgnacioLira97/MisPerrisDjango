from django.contrib import admin
from misperrisweb.apps.Misperris.models import *


admin.site.register(region)
admin.site.register(comuna)
admin.site.register(tipoUsuario)
admin.site.register(tipoVivienda)
admin.site.register(sexo)
admin.site.register(usuario)
admin.site.register(raza)
admin.site.register(estado)
admin.site.register(perro)
admin.site.register(adopcion)
